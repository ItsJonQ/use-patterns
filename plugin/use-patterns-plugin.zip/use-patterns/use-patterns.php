<?php
   /*
   Plugin Name: Use Patterns
   Plugin URI: https://use-patterns.vercel.app/
   description: >-
  Curated Gutenberg Block Patterns
   Version: 1.0.0
   Author: Jon Quach
   Author URI: https://jonquach.com/
   License: GPL2
   */


function use_patterns_load_stylesheets() {
    $plugin_url = plugin_dir_url( __FILE__ );
    wp_enqueue_style( 'style',  $plugin_url . "/tachyons.css");
}

function use_patterns_load_scripts() {
    $plugin_url = plugin_dir_url( __FILE__ );
    wp_enqueue_script( 'script',  $plugin_url . "/patterns.js");
}

add_action( 'wp_enqueue_scripts', 'use_patterns_load_stylesheets' );
add_action( 'admin_print_styles', 'use_patterns_load_stylesheets' );
add_action( 'admin_print_styles', 'use_patterns_load_scripts' );