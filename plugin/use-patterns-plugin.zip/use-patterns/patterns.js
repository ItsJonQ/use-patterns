(() => {
	try {
		let index = undefined;
		const handleOnDrop = (event) => {
			const data = event.dataTransfer.getData('text');
			const parsed = JSON.parse(data);

			const contentSrc = parsed.contentSrc;
			const rawContent = parsed.rawContent;

			if (contentSrc !== 'use_patterns') return;

			event.preventDefault();
			event.stopPropagation();

			const blocks = wp.blocks.pasteHandler({ HTML: rawContent });

			const dropTarget = document.querySelector('.is-drop-target');
			const dropTargetBlock =
				dropTarget && dropTarget.closest('.wp-block');
			const rootContainer = document.querySelector('.is-root-container');

			index = Array.from(rootContainer.childNodes).indexOf(
				dropTargetBlock
			);

			if (index < 0) {
				index = undefined;
			}

			console.log(index);

			wp.data.dispatch('core/block-editor').insertBlocks(blocks, index);
		};

		document.addEventListener('drop', handleOnDrop);
		document.addEventListener('dragover', () => {});
	} catch (err) {}
})();
